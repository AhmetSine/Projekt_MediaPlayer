﻿namespace MediaPlayer
{
    partial class FormAnmeldung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAnmelden = new System.Windows.Forms.Button();
            this.labelBenutzername = new System.Windows.Forms.Label();
            this.textBoxBenutzername = new System.Windows.Forms.TextBox();
            this.textBoxPasswort = new System.Windows.Forms.TextBox();
            this.labelPasswort = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelPasswortReg = new System.Windows.Forms.Label();
            this.textBoxPasswortReg = new System.Windows.Forms.TextBox();
            this.textBoxBenutzernameReg = new System.Windows.Forms.TextBox();
            this.labelBenutzernameReg = new System.Windows.Forms.Label();
            this.buttonRegistrieren = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAnmelden
            // 
            this.buttonAnmelden.Location = new System.Drawing.Point(120, 112);
            this.buttonAnmelden.Name = "buttonAnmelden";
            this.buttonAnmelden.Size = new System.Drawing.Size(75, 23);
            this.buttonAnmelden.TabIndex = 0;
            this.buttonAnmelden.Text = "anmelden";
            this.buttonAnmelden.UseVisualStyleBackColor = true;
            // 
            // labelBenutzername
            // 
            this.labelBenutzername.AutoSize = true;
            this.labelBenutzername.Location = new System.Drawing.Point(17, 63);
            this.labelBenutzername.Name = "labelBenutzername";
            this.labelBenutzername.Size = new System.Drawing.Size(75, 13);
            this.labelBenutzername.TabIndex = 1;
            this.labelBenutzername.Text = "Benutzername";
            // 
            // textBoxBenutzername
            // 
            this.textBoxBenutzername.Location = new System.Drawing.Point(98, 60);
            this.textBoxBenutzername.Name = "textBoxBenutzername";
            this.textBoxBenutzername.Size = new System.Drawing.Size(114, 20);
            this.textBoxBenutzername.TabIndex = 2;
            // 
            // textBoxPasswort
            // 
            this.textBoxPasswort.Location = new System.Drawing.Point(98, 86);
            this.textBoxPasswort.Name = "textBoxPasswort";
            this.textBoxPasswort.Size = new System.Drawing.Size(114, 20);
            this.textBoxPasswort.TabIndex = 3;
            // 
            // labelPasswort
            // 
            this.labelPasswort.AutoSize = true;
            this.labelPasswort.Location = new System.Drawing.Point(42, 89);
            this.labelPasswort.Name = "labelPasswort";
            this.labelPasswort.Size = new System.Drawing.Size(50, 13);
            this.labelPasswort.TabIndex = 4;
            this.labelPasswort.Text = "Passwort";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(107, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Anmeldung";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(328, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Registrierung";
            // 
            // labelPasswortReg
            // 
            this.labelPasswortReg.AutoSize = true;
            this.labelPasswortReg.Location = new System.Drawing.Point(276, 89);
            this.labelPasswortReg.Name = "labelPasswortReg";
            this.labelPasswortReg.Size = new System.Drawing.Size(50, 13);
            this.labelPasswortReg.TabIndex = 10;
            this.labelPasswortReg.Text = "Passwort";
            // 
            // textBoxPasswortReg
            // 
            this.textBoxPasswortReg.Location = new System.Drawing.Point(332, 86);
            this.textBoxPasswortReg.Name = "textBoxPasswortReg";
            this.textBoxPasswortReg.Size = new System.Drawing.Size(113, 20);
            this.textBoxPasswortReg.TabIndex = 9;
            // 
            // textBoxBenutzernameReg
            // 
            this.textBoxBenutzernameReg.Location = new System.Drawing.Point(332, 60);
            this.textBoxBenutzernameReg.Name = "textBoxBenutzernameReg";
            this.textBoxBenutzernameReg.Size = new System.Drawing.Size(113, 20);
            this.textBoxBenutzernameReg.TabIndex = 8;
            // 
            // labelBenutzernameReg
            // 
            this.labelBenutzernameReg.AutoSize = true;
            this.labelBenutzernameReg.Location = new System.Drawing.Point(251, 63);
            this.labelBenutzernameReg.Name = "labelBenutzernameReg";
            this.labelBenutzernameReg.Size = new System.Drawing.Size(75, 13);
            this.labelBenutzernameReg.TabIndex = 7;
            this.labelBenutzernameReg.Text = "Benutzername";
            // 
            // buttonRegistrieren
            // 
            this.buttonRegistrieren.Location = new System.Drawing.Point(354, 112);
            this.buttonRegistrieren.Name = "buttonRegistrieren";
            this.buttonRegistrieren.Size = new System.Drawing.Size(75, 23);
            this.buttonRegistrieren.TabIndex = 6;
            this.buttonRegistrieren.Text = "registrieren";
            this.buttonRegistrieren.UseVisualStyleBackColor = true;
            // 
            // FormAnmeldung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 271);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelPasswortReg);
            this.Controls.Add(this.textBoxPasswortReg);
            this.Controls.Add(this.textBoxBenutzernameReg);
            this.Controls.Add(this.labelBenutzernameReg);
            this.Controls.Add(this.buttonRegistrieren);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelPasswort);
            this.Controls.Add(this.textBoxPasswort);
            this.Controls.Add(this.textBoxBenutzername);
            this.Controls.Add(this.labelBenutzername);
            this.Controls.Add(this.buttonAnmelden);
            this.Name = "FormAnmeldung";
            this.ShowIcon = false;
            this.Text = "Anmeldung";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAnmelden;
        private System.Windows.Forms.Label labelBenutzername;
        private System.Windows.Forms.TextBox textBoxBenutzername;
        private System.Windows.Forms.TextBox textBoxPasswort;
        private System.Windows.Forms.Label labelPasswort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelPasswortReg;
        private System.Windows.Forms.TextBox textBoxPasswortReg;
        private System.Windows.Forms.TextBox textBoxBenutzernameReg;
        private System.Windows.Forms.Label labelBenutzernameReg;
        private System.Windows.Forms.Button buttonRegistrieren;
    }
}