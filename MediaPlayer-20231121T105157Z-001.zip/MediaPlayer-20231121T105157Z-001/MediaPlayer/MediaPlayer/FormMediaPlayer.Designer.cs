﻿namespace MediaPlayer
{
    partial class FormMediaPlayer
    {

        private System.ComponentModel.IContainer components = null;

        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMediaPlayer));
            this.panelTop = new System.Windows.Forms.Panel();
            this.labelFile = new System.Windows.Forms.Label();
            this.buttonDateiOeffnen = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panelMain = new System.Windows.Forms.Panel();
            this.WindowsMP = new AxWMPLib.AxWindowsMediaPlayer();
            this.buttonAnmeldenMain = new System.Windows.Forms.Button();
            this.labelAnmeldename = new System.Windows.Forms.Label();
            this.panelTop.SuspendLayout();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WindowsMP)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.labelAnmeldename);
            this.panelTop.Controls.Add(this.buttonAnmeldenMain);
            this.panelTop.Controls.Add(this.labelFile);
            this.panelTop.Controls.Add(this.buttonDateiOeffnen);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(864, 47);
            this.panelTop.TabIndex = 2;
            // 
            // labelFile
            // 
            this.labelFile.AutoSize = true;
            this.labelFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelFile.Location = new System.Drawing.Point(354, 16);
            this.labelFile.Name = "labelFile";
            this.labelFile.Size = new System.Drawing.Size(169, 16);
            this.labelFile.TabIndex = 3;
            this.labelFile.Text = "Keine Datei ausgewählt";
            // 
            // buttonDateiOeffnen
            // 
            this.buttonDateiOeffnen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDateiOeffnen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDateiOeffnen.Location = new System.Drawing.Point(772, 12);
            this.buttonDateiOeffnen.Name = "buttonDateiOeffnen";
            this.buttonDateiOeffnen.Size = new System.Drawing.Size(80, 23);
            this.buttonDateiOeffnen.TabIndex = 2;
            this.buttonDateiOeffnen.Text = "Datei öffnen";
            this.buttonDateiOeffnen.UseVisualStyleBackColor = true;
            this.buttonDateiOeffnen.Click += new System.EventHandler(this.buttonDateiOeffnen_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panelMain
            // 
            this.panelMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelMain.Controls.Add(this.WindowsMP);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(864, 455);
            this.panelMain.TabIndex = 0;
            // 
            // WindowsMP
            // 
            this.WindowsMP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WindowsMP.Enabled = true;
            this.WindowsMP.Location = new System.Drawing.Point(0, 0);
            this.WindowsMP.Name = "WindowsMP";
            this.WindowsMP.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("WindowsMP.OcxState")));
            this.WindowsMP.Size = new System.Drawing.Size(864, 455);
            this.WindowsMP.TabIndex = 0;
            // 
            // buttonAnmeldenMain
            // 
            this.buttonAnmeldenMain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAnmeldenMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAnmeldenMain.Location = new System.Drawing.Point(12, 12);
            this.buttonAnmeldenMain.Name = "buttonAnmeldenMain";
            this.buttonAnmeldenMain.Size = new System.Drawing.Size(88, 23);
            this.buttonAnmeldenMain.TabIndex = 4;
            this.buttonAnmeldenMain.Text = "Anmelden";
            this.buttonAnmeldenMain.UseVisualStyleBackColor = true;
            // 
            // labelAnmeldename
            // 
            this.labelAnmeldename.AutoSize = true;
            this.labelAnmeldename.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAnmeldename.Location = new System.Drawing.Point(106, 16);
            this.labelAnmeldename.Name = "labelAnmeldename";
            this.labelAnmeldename.Size = new System.Drawing.Size(128, 16);
            this.labelAnmeldename.TabIndex = 5;
            this.labelAnmeldename.Text = "Nicht angemeldet";
            // 
            // FormMediaPlayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 455);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelMain);
            this.Name = "FormMediaPlayer";
            this.ShowIcon = false;
            this.Text = "MediaPlayer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.WindowsMP)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Button buttonDateiOeffnen;
        private System.Windows.Forms.Label labelFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panelMain;
        private AxWMPLib.AxWindowsMediaPlayer WindowsMP;
        private System.Windows.Forms.Label labelAnmeldename;
        private System.Windows.Forms.Button buttonAnmeldenMain;
    }
}

